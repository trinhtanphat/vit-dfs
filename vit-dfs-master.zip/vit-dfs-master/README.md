# vit-dfs

Minh họa thuật toán tìm đường trong mê cung bằng một con vịt

[![Build and Deploy](https://github.com/thangved/vit-dfs/actions/workflows/github-pages-deploy.yml/badge.svg)](https://github.com/thangved/vit-dfs/actions/workflows/github-pages-deploy.yml)
[![Deploy to Firebase Hosting on merge](https://github.com/thangved/vit-dfs/actions/workflows/firebase-hosting-merge.yml/badge.svg)](https://github.com/thangved/vit-dfs/actions/workflows/firebase-hosting-merge.yml)
[![Deploy to Firebase Hosting on PR](https://github.com/thangved/vit-dfs/actions/workflows/firebase-hosting-pull-request.yml/badge.svg)](https://github.com/thangved/vit-dfs/actions/workflows/firebase-hosting-pull-request.yml)
[![NodeJS with Webpack](https://github.com/thangved/vit-dfs/actions/workflows/webpack.yml/badge.svg)](https://github.com/thangved/vit-dfs/actions/workflows/webpack.yml)
[![pages-build-deployment](https://github.com/thangved/vit-dfs/actions/workflows/pages/pages-build-deployment/badge.svg)](https://github.com/thangved/vit-dfs/actions/workflows/pages/pages-build-deployment)
